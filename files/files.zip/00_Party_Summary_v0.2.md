# Standard Party Summary — Baseline Configuration (CORRECTED v0.2)

**Purpose:** Fixed four-person control party used for all baseline and homebrew testing. Composition never changes across tests. Subclass tests add a fifth member to measure their contribution.

**Corrections from v0.1:**
- Ability score increases now from background (2024 rules), not species
- Origin feats correctly distributed (Human grants one feat choice; background grants one feat)
- Background choices adjusted to avoid feat conflicts
- Life Cleric, Life Domain spell list corrected
- Battle Master, Thief, Evoker subclass features at correct levels
- Divine Intervention at L10 (not L20)
- Greater Divine Intervention at L20 (casts Wish)
- Blessed Strikes as L7 base cleric feature (choice of Divine Strike or Potent Spellcasting)

---

## Party Composition

| Name | Class | Subclass | Role | Primary Stat |
|------|-------|----------|------|--------------|
| **Garrick Ironward** | Fighter | Battle Master | Tank, melee DPR, control | STR |
| **Elowyn Dawnbrook** | Cleric | Life (Thaumaturge order) | Healer, buffer, utility | WIS |
| **Varian Thornweave** | Wizard | Evocation (Evoker) | Caster DPR, control, counter | INT |
| **Mira Shadowstep** | Rogue | Thief | Ranged DPR, skills, scout | DEX |

All characters are Human (2024 lineage). Standard array (15, 14, 13, 12, 10, 8). Ability scores adjusted by +2/+1 from background per 2024 rules.

---

## Design Rationale

**Why these four subclasses:**
- **Battle Master Fighter:** Well-tuned martial baseline. Maneuvers + Weapon Mastery (Sap, Vex, Slow) provide rich combat without breaking balance.
- **Life Cleric (Thaumaturge):** Canonical healer. Thaumaturge order chosen over Protector to keep Elowyn caster-focused (no heavy armor, emphasizing spellcasting).
- **Evocation Wizard:** Iconic controller-damager. Sculpt Spells (L6) prevents friendly fire for AoE. Well-understood baseline.
- **Thief Rogue:** Strong skill coverage, reliable ranged Sneak Attack. Chosen over Gloom Stalker (surprise-round distortion) and Assassin (underpowered post-surprise).

**Why a five-member party for tests:**
- Adding the subclass under test as a fifth member changes ONE variable. Swapping into an existing slot changes two.
- Absolute win rates skew slightly higher than 4-player play, but consistent across all tests.
- Phase 0 (standard party alone) establishes baseline 4-player performance.
- Phase 1+ tests measure delta from baseline.

---

## Feat Summary Across Party (2024 Rules)

| Character | Origin (Human) | Background | Background Feat | L4 ASI | L6 bonus | L8 ASI | L10 | L12 ASI | L14 bonus | L16 ASI | L19 Epic Boon |
|-----------|----------------|------------|-----------------|--------|---------:|--------|-----|---------|-----------|---------|---------------|
| Garrick | Tough | Soldier | Savage Attacker | Resilient (WIS) | +2 STR (to 18) | +2 STR (to 20) | — | Alert | Lucky | Resilient (CON) | Boon of Combat Prowess |
| Elowyn | Healer | Acolyte | Magic Initiate (Cleric) | +2 WIS (to 19) | — | +1 WIS (to 20), +1 CON | — | War Caster | — | Resilient (DEX) | Boon of Fate |
| Varian | Alert | Sage | Magic Initiate (Wizard) | War Caster | — | +2 INT (to 19) | — | +1 INT (to 20), +1 CON | — | Resilient (CON) | Boon of Spell Recall |
| Mira | Alert | Charlatan | Skilled | +2 DEX (to 19) | — | +1 DEX (to 20), +1 CON | Lucky | Resilient (WIS) | — | Skulker | Boon of the Night Spirit |

**Note:** Fighter gets bonus feats at levels 6 AND 14 on top of standard ASIs at 4, 8, 12, 16.

**Background ability score distribution:**
- Garrick (Soldier): STR +2, CON +1
- Elowyn (Acolyte): WIS +2, CHA +1
- Varian (Sage): INT +2, WIS +1
- Mira (Charlatan): DEX +2, CON +1

---

## Magic Item Distribution Summary (2024 DMG Guidelines)

Follows 2024 DMG "Magic Items Awarded by Level" table, distributed by class role priority:
- **Garrick (martial):** Weapon and armor priority
- **Elowyn (support):** Periapts, protective items, healing focus
- **Varian (caster):** Wands, staves, caster robes
- **Mira (skill/ranged):** Elvenkind items, +crossbow, evasion rings

Total magic items per character by level 20: ~7-9 each.

---

## Spellcasting Overview

### Elowyn (Life Cleric) Key Access Levels
- L1: 1st-level slots (2), prepared spell count per class table
- L3: 2nd-level slots; Disciple of Life + Preserve Life (new targeting only Bloodied)
- L5: 3rd-level slots → Spirit Guardians online
- L7: 4th-level slots; Blessed Strikes choice (Potent Spellcasting chosen); Life Domain adds Aura of Life, Death Ward
- L9: 5th-level slots → Flame Strike, Mass Cure Wounds, Greater Restoration
- L10: Divine Intervention unlocks (5th-level-or-lower spell, 1/long rest)
- L11: 6th-level slots → Heal, Heroes' Feast
- L13: 7th-level slots → Resurrection, Regenerate
- L14: Improved Blessed Strikes (Potent Spellcasting upgrade)
- L15: 8th-level slots → Holy Aura, Sunburst
- L17: 9th-level slots → Mass Heal, True Resurrection; Life Domain: Supreme Healing (max healing on dice)
- L20: Greater Divine Intervention (can cast Wish via DI)

### Varian (Evocation Wizard) Key Access Levels
- L1: 1st-level slots (2), prepared = level + INT mod
- L3: 2nd-level slots; Evoker subclass (Evocation Savant, Potent Cantrip) → Scorching Ray, Misty Step, Web online
- L5: 3rd-level slots → Fireball, Counterspell, Fly, Haste online
- L6: Sculpt Spells (exclude allies from Evocation AoE)
- L7: 4th-level slots → Polymorph, Banishment
- L9: 5th-level slots → Wall of Force, Cone of Cold
- L10: Empowered Evocation (add INT mod to one damage roll per Evocation spell)
- L11: 6th-level slots → Chain Lightning, Disintegrate
- L13: 7th-level slots → Forcecage, Teleport
- L14: Overchannel (max damage on 1st-5th level evocation spell, 1/long rest first free)
- L15: 8th-level slots → Maze, Power Word Stun
- L17: 9th-level slots → Meteor Swarm, Wish
- L18: Spell Mastery (Shield, Misty Step at will)
- L20: Signature Spells (Fireball, Counterspell once per short rest free)

---

## Known Simplifications for Simulation

1. **Feat choices locked.** Even if a sim situation would favor a different feat, these feats are used.
2. **Spell preparation illustrative, not exhaustive.** Actual prepared lists enumerated per level in sim engine.
3. **Magic item acquisition levels fixed.** Items arrive at specified levels.
4. **No multiclassing.** All four stay single-class through level 20.
5. **Human lineage fixed.** Species variance tested separately.
6. **Behavior AI competent tactical, not optimized.** Characters play reasonably but don't execute min-max combos beyond natural class support.

---

## Revision Tracking

- v0.1 (initial): Four-person party defined with character sheets
- **v0.2 (current): Corrected against verified 2024/5.5e rules:**
  - Background-based ASIs (not species)
  - Subclass feature levels corrected (Battle Master 3/7/10/15/18; Life Cleric 3/6/14/17; Evoker 3/6/10/14; Thief 3/9/13/17)
  - 2024 Cleric Divine Intervention timing (L10, not dependent on d100 roll)
  - 2024 Life Domain spell list (Aid, Mass Healing Word, Aura of Life, Greater Restoration in; Spiritual Weapon, Beacon of Hope, Guardian of Faith, Raise Dead out)
  - Life Domain no longer grants heavy armor
  - Preserve Life targets Bloodied only; works on Undead/Constructs
  - Blessed Strikes as level 7 base cleric feature (choice of Divine Strike or Potent Spellcasting)
  - Monster schema updated to 2025 MM format
