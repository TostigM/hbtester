# Mira Shadowstep — Standard Party Member 4 (CORRECTED v0.2)
## Human Thief Rogue

**Corrections from v0.1:**
- Thief subclass features confirmed at levels 3, 9, 13, 17 (NOT 14):
  - Level 3: Fast Hands, Second-Story Work
  - Level 9: Supreme Sneak (now a Cunning Strike option, not standalone stealth bonus)
  - Level 13: Use Magic Device (attunement to 4 items; special benefits)
  - Level 17: Thief's Reflexes (two turns in round 1)
- Rogue 2024: Subclass at level 3, Cunning Strike at level 5 (new feature), Improved Cunning Strike at level 11 (new), Devious Strikes at level 14 (new)
- Reliable Talent at level 11 (not changed)
- Slippery Mind at level 15: grants WIS and CHA save proficiency (both), not just CHA
- Elusive at level 18: same as 2014
- Stroke of Luck at level 20: same mechanic
- Sneak Attack caps at 10d6 at level 19
- Background choice corrected: Criminal grants Alert (conflict with Human Alert). Switched to Charlatan (grants Skilled)
- Ability score increases from background; Charlatan grants +2/+1 among DEX, CON, CHA
- Mira's ASI allocation: DEX +2, CON +1

---

## Core Identity

**Species:** Human
**Class:** Rogue (Thief subclass at level 3)
**Background:** Charlatan (changed from Criminal due to feat conflict)
**Alignment:** Chaotic Good (flavor)
**Role in Party:** Ranged damage, scout, skill specialist (stealth, perception, thieves' tools), utility expert

---

## Ability Scores (Standard Array + Background ASI, Final)

| Ability | Base | Background ASI | Level 1 | Post-ASI Peak |
|---------|------|----------------|---------|---------------|
| DEX | 15 | +2 (Charlatan: DEX/CON/CHA) | **17** | **20** (at level 8 ASI) |
| CON | 14 | +1 | **15** | 15 |
| WIS | 13 | — | 13 | 14 (at L12 Resilient WIS) |
| INT | 12 | — | 12 | 12 |
| CHA | 10 | — | 10 | 10 |
| STR | 8 | — | 8 | 8 |

Starting HP at L1: 8 (rogue base) + 2 (CON mod) = **10 HP**

---

## Origin Feat (from Human lineage)

**Alert** — Initiative bonus equal to proficiency bonus. Cannot be surprised.

**Rationale:** Mira wants to act first in combat to Hide (bonus action) for advantage on first attack, guaranteeing Sneak Attack. Alert + Dex build = top initiative.

---

## Background: Charlatan (2024)

**Background Ability Scores:** DEX, CON, CHA (grants +2/+1 OR three +1s)
**Chosen allocation:** DEX +2, CON +1

**Origin Feat (Charlatan grant):** Skilled
- Gain proficiency in any 3 skills or tools of your choice
- Chosen: **Deception, Insight, Investigation**

**Skill Proficiencies (Charlatan base):** Deception, Sleight of Hand
**Tool Proficiency:** Forgery Kit
**Starting Equipment (Charlatan):** Fine Clothes, Disguise Kit, Forgery Kit, Signet Ring (fake), 15 GP (or 50 GP alternative)

---

## Rogue Class Features (2024)

- **Expertise** at level 1: 2 skills (chosen: **Stealth, Thieves' Tools**); 2 more at level 6
- **Sneak Attack** (scales each rogue level):
  - 1d6 at L1; 2d6 at L3; 3d6 at L5; 4d6 at L7; 5d6 at L9; 6d6 at L11; 7d6 at L13; 8d6 at L15; 9d6 at L17; 10d6 at L19
- **Thieves' Cant** at level 1
- **Weapon Mastery** at level 1 (2 weapon masteries chosen from Simple + Finesse/Light Martial)
  - Chosen: **Shortsword (Vex), Hand Crossbow (Vex)**
  - Wait — Rogue 2024 grants only 2 Weapon Masteries. Chosen: Shortsword (Vex), Hand Crossbow (Vex). Fighter has 3; Rogue has 2.
- **Cunning Action** at level 2 (bonus action: Dash, Disengage, or Hide)
- **Subclass at level 3** (Thief)
- **Steady Aim** at level 3 (new 2024 feature — bonus action, next attack has advantage but speed 0 this turn)
- **Ability Score Improvement** levels 4, 8, 10, 12, 16 (and Epic Boon at 19)
- **Cunning Strike** at level 5 (new 2024: spend sneak attack dice for effects)
- **Uncanny Dodge** at level 5 (reaction: halve damage from one attack)
- **Expertise** bump to 2 more skills at level 6
- **Evasion** at level 7
- **Reliable Talent** at level 11 (treat d20 as 10 minimum on proficient ability checks)
- **Improved Cunning Strike** at level 11 (new: apply 2 Cunning Strike effects instead of 1)
- **Devious Strikes** at level 14 (new 2024: additional Cunning Strike options like Disarm, Daze, Knock Out)
- **Slippery Mind** at level 15 (gain proficiency in WIS AND CHA saves)
- **Elusive** at level 18 (no attack has advantage against you unless incapacitated)
- **Stroke of Luck** at level 20 (once per short rest: turn miss into hit, or treat failed ability check as 20)

---

## Weapon Mastery (Rogue gets 2)

- **Shortsword (Vex)**: First hit grants advantage on next attack vs same target
- **Hand Crossbow (Vex)**: Same, for ranged

---

## Level-by-Level Progression

### Tier 1 (Levels 1–4)

**Level 1**
- Class features: Expertise (Stealth, Thieves' Tools), Sneak Attack 1d6, Thieves' Cant, Weapon Mastery (2)
- Origin feat: Alert
- Background feat: Skilled (+3 skills: Deception, Insight, Investigation)
- Skill proficiencies (8 total): 
  - Rogue class (pick 4 from rogue list): **Stealth, Perception, Acrobatics, Thieves' Tools**
  - Charlatan: **Deception, Sleight of Hand**
  - Skilled bonus: **Insight, Investigation**
  - Final 8: Stealth, Perception, Acrobatics, Thieves' Tools, Deception, Sleight of Hand, Insight, Investigation
  - Expertise in: Stealth, Thieves' Tools
- Equipment: Leather Armor, Shortsword, Hand Crossbow (20 bolts), Dagger (×2), Thieves' Tools, Burglar's Pack
- HP: 10
- AC: 11 (Leather) + 3 (DEX 17) = **14**
- Initiative: +3 (DEX) + 2 (Alert/prof bonus) = **+5**

**Level 2**
- Cunning Action (Dash, Disengage, Hide as bonus action)
- HP: 17

**Level 3**
- Subclass: Thief
  - **Fast Hands**: As bonus action can make Sleight of Hand check with Thieves' Tools, use an Object action, or take the Magic action to use a magic item requiring that action
  - **Second-Story Work**: Climb speed equal to walking speed; jump distance uses DEX instead of STR
- Steady Aim (class feature at L3; bonus action: next attack has advantage if you don't move this turn)
- Sneak Attack: 2d6
- HP: 24

**Level 4**
- ASI: **+2 DEX (17→19)**
- HP: 31
- AC: 11 + 4 (DEX 19) = **15**
- **Equipment:** +1 Hand Crossbow (uncommon) — primary weapon upgrade

### Tier 2 (Levels 5–10)

**Level 5**
- Cunning Strike (new 2024): Can spend sneak attack dice to apply effects:
  - Poison (1d6 Sneak Attack dice): target poisoned until end of next turn
  - Trip (1d6): target prone if Small or Medium
  - Withdraw (1d6): move half speed after attack without provoking OA
- Uncanny Dodge (reaction: halve damage from one attack)
- Sneak Attack: 3d6
- HP: 38
- **Equipment:** +1 Studded Leather (uncommon) — AC: 12 + 4 + 1 = **17**

**Level 6**
- Expertise (2 more skills): **Perception, Acrobatics**
- HP: 45

**Level 7**
- Evasion (succeed on DEX save = no damage from effect that normally deals half on save; failed save = half)
- Sneak Attack: 4d6
- HP: 52
- **Equipment:** Cloak of Elvenkind (uncommon) — advantage on Stealth while hooded

**Level 8**
- ASI: **+1 DEX (19→20)**, **+1 CON (15→16)** 
  - Wait, +1+1 or +2 to one. +2 DEX would go to 20 (capped). +1 DEX to 20, +1 CON to 16 for HP. 
  - **Chosen: +1 DEX to 20, +1 CON to 16** (for extra HP from CON 16)
- HP: 60 (with retroactive CON 16 bump)
- Spell attack / to-hit increases
- **Equipment:** Boots of Elvenkind (uncommon) — steps silent, advantage on Stealth (stacks with Cloak for redundancy)

**Level 9**
- Thief subclass: **Supreme Sneak** — Cunning Strike option: when you Hide and remain behind 3/4 or total cover at end of turn, the Hide's Invisible condition doesn't end on you (allows chain sneak attacks from hiding)
- Sneak Attack: 5d6
- HP: 67

**Level 10**
- ASI: **Lucky** feat (3 luck points per long rest; reroll attack/save/check)
- HP: 74
- **Equipment:** Ring of Mind Shielding (uncommon)

### Tier 3 (Levels 11–15)

**Level 11**
- Reliable Talent (treat d20 as 10 for any proficient ability check)
- Improved Cunning Strike (new 2024; use 2 Cunning Strike effects with one attack instead of 1)
- Sneak Attack: 6d6
- HP: 81
- **Equipment:** +2 Hand Crossbow (very rare) — primary weapon upgrade

**Level 12**
- ASI: **Resilient (WIS)** — +1 WIS (13→14), WIS save proficiency (critical defense against mind effects)
- HP: 88

**Level 13**
- Thief subclass: **Use Magic Device** — can attune to up to 4 magic items (vs normal 3); when using a magic item that has charges, can roll d6 on use and recover a charge on a 6
- Sneak Attack: 7d6
- HP: 95
- **Equipment:** Sending Stones (uncommon) — out-of-combat utility

**Level 14**
- Devious Strikes (new 2024): Additional Cunning Strike options become available (Daze, Knock Out, Disarm, Obscure)
  - Daze (2d6): target's speed 0 until end of next turn
  - Knock Out (6d6 and hit): target falls unconscious 1 hour
  - Disarm (1d6 and hit): target drops one held item
  - Obscure (2d6): target blinded until end of next turn
- HP: 102
- **Equipment:** Ring of Evasion (rare) — 3 charges; reaction to auto-succeed DEX save

**Level 15**
- Slippery Mind (gain proficiency in WIS AND CHA saves; WIS is already via Resilient, so this primarily adds CHA)
- Sneak Attack: 8d6
- HP: 109

### Tier 4 (Levels 16–20)

**Level 16**
- ASI: **Skulker** feat — hide when lightly obscured, missing with ranged doesn't reveal position, no disadvantage on perception in dim light
- HP: 116
- **Equipment:** +3 Studded Leather (very rare) — AC: 12 + 5 + 3 = **20**

**Level 17**
- Thief subclass capstone: **Thief's Reflexes** — take two turns during round 1 of combat (first turn normal initiative, second turn at initiative -10); doesn't work if surprised
- Sneak Attack: 9d6
- HP: 123

**Level 18**
- Elusive (no attack has advantage against you while not incapacitated)
- HP: 130
- **Equipment:** Cape of the Mountebank (rare) — cast Dimension Door 1/day

**Level 19**
- Epic Boon: **Boon of the Night Spirit** — +1 DEX (20→21, Epic Boon exceeds 20 cap)
  - While fully in dim light or darkness, resistance to all damage except force/psychic/radiant; can Hide as bonus action (redundant with Cunning Action for Thief, but stacks with Skulker for extreme stealth)
- Sneak Attack: 10d6
- HP: 137

**Level 20**
- Stroke of Luck (once per short rest: turn miss into hit OR treat failed check as 20)
- HP: 144
- **Equipment:** +3 Hand Crossbow (legendary-equivalent custom) — primary weapon capstone

---

## Signature Tactical Patterns by Tier

### Tier 1 (Levels 1–4)
- Opening: Steady Aim (L3+) bonus action for advantage; Hand Crossbow + Sneak Attack
- Positioning: Stay at ranged distance (30/120 ft hand crossbow)
- Utility: Expertise Stealth + Alert = reliable scouting

### Tier 2 (Levels 5–10)
- Cunning Strike combos (L5): spend Sneak Attack dice for effects (Trip, Withdraw, Poison)
- Uncanny Dodge: half damage reaction for big hits
- Evasion (L7): save against area spells
- Fast Hands: bonus action item use (healer's kit, potions, magic items)

### Tier 3 (Levels 11–15)
- Reliable Talent: never fail a proficient skill check
- Improved Cunning Strike (L11): 2 effects per attack (e.g., Trip + Poison)
- Use Magic Device (L13): 4 attunement slots; wand/scroll flexibility
- Sneak Attack 6d6-8d6 consistently

### Tier 4 (Levels 16–20)
- Thief's Reflexes (L17): TWO turns round 1 = alpha strike devastation
  - Turn 1: Attack + Sneak Attack + Cunning Strike (with Improved Cunning Strike using 2 effects)
  - Turn 1 bonus: Steady Aim or Hide for next turn
  - Turn 2 (later in round): Attack + Sneak Attack (fresh)
- Elusive (L18): no advantage against you; dramatic survivability boost
- Sneak Attack 9d6-10d6 with Thief's Reflexes = burst peak

---

## Magic Item Summary

| Level | Item | Rarity |
|-------|------|--------|
| 4 | +1 Hand Crossbow | Uncommon |
| 5 | +1 Studded Leather | Uncommon |
| 7 | Cloak of Elvenkind | Uncommon |
| 8 | Boots of Elvenkind | Uncommon |
| 10 | Ring of Mind Shielding | Uncommon |
| 11 | +2 Hand Crossbow | Very Rare |
| 13 | Sending Stones | Uncommon |
| 14 | Ring of Evasion | Rare |
| 16 | +3 Studded Leather | Very Rare |
| 18 | Cape of the Mountebank | Rare |
| 20 | +3 Hand Crossbow | Legendary-equivalent |

---

## AC Progression

| Level | Armor | DEX Mod | Total AC |
|-------|-------|---------|----------|
| 1-4 | Leather (11) | +3 | 14 |
| 4 (after ASI) | Leather | +4 | 15 |
| 5-7 | +1 Studded (12+1) | +4 | 17 |
| 8-15 | +1 Studded | +5 (DEX 20) | 18 |
| 16-19 | +3 Studded (12+3) | +5 | 20 |
| 20 | +3 Studded | +5 (DEX 21 from Epic Boon) | 20 (DEX cap at +5 via Light Armor rules? — actually Studded Leather allows full DEX mod, so 21 DEX would add +5 still; Epic Boon +1 DEX to 21 gives +5 mod, no change to AC from this) |

---

## Simulation Notes

**Primary combat pattern:**
- Opening: Hide (bonus action via Cunning Action) then attack with advantage for guaranteed Sneak Attack, OR Steady Aim if exposed
- Main rounds: Attack action + Cunning Action (Hide/Dash/Disengage)
- Vex mastery: Alternate between Shortsword and Hand Crossbow; first hit grants advantage on next attack same target
- Cunning Strike (L5+): Trade some Sneak Attack dice for effects when target needs to be controlled
- Emergency: Uncanny Dodge (halve damage), Evasion (negate area saves), Lucky point reroll

**Stealth dominance:** Cloak + Boots of Elvenkind + Expertise Stealth + Reliable Talent = rarely fail at reconnaissance. Skulker at L16 enables hiding in light cover.

**Key weaknesses:** Single attack per turn (no Extra Attack ever), limited AoE damage, depends on positioning for advantage/Sneak Attack setup. Low HP compared to martial baseline.

**Behavior AI priorities:**
1. Turn 1: Hide (bonus action) if not yet seen; OR Steady Aim if exposed (advantage on next attack)
2. Sneak Attack setup: prioritize advantage (hide, flank, Steady Aim)
3. Target selection: focus highest-threat (spellcasters, damage dealers, boss) to apply pressure
4. Positioning: ranged distance (Hand Crossbow 30/120 ft), use Thief mobility for vantage
5. Resource management: Uncanny Dodge for big hits; Ring of Evasion charges for big AoE spells
6. Solo endurance: kite with Cunning Action Dash/Disengage; use Hide to reset advantage each turn
7. Thief's Reflexes opening (L17+): use first turn for full alpha strike, second turn for followup
