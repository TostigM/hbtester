# Varian Thornweave — Standard Party Member 3 (CORRECTED v0.2)
## Human Evocation Wizard (Evoker)

**Corrections from v0.1:**
- Ability score increases now come from background (Sage), not species (Human grants no ASI)
- Sage background in 2024 grants +2/+1 among INT, WIS, CHA (corrected distribution)
- Evoker subclass features confirmed at levels 3, 6, 10, 14 in 2024 rules:
  - Level 3: Evocation Savant, Potent Cantrip
  - Level 6: Sculpt Spells
  - Level 10: Empowered Evocation
  - Level 14: Overchannel
- Wizard 2024: Subclass at level 3 (confirmed, was level 2 in 2014)
- Spell Mastery at level 18 (not changed)
- Signature Spells at level 20 (not changed)
- Wizard gains 2 cantrips at level 4, 10 (for total of 5 at 4, and capstone cantrips learnt)
- Ritual Adept replaces 2014's Ritual Casting; simpler formulation
- Scholar at level 2 (2024 feature: expertise in one Int-based skill)

---

## Core Identity

**Species:** Human
**Class:** Wizard (Evoker/Evocation subclass at level 3)
**Background:** Sage
**Alignment:** Neutral Good (flavor)
**Role in Party:** Primary damage caster, battlefield control, utility specialist, counterspell defense

---

## Ability Scores (Standard Array + Background ASI, Final)

| Ability | Base | Background ASI | Level 1 | Post-ASI Peak |
|---------|------|----------------|---------|---------------|
| INT | 15 | +2 (Sage: INT/WIS/CHA) | **17** | **20** (at level 8 ASI) |
| CON | 14 | — | 14 | **16** (at level 12 Resilient CON) |
| WIS | 12 | +1 | **13** | 13 |
| DEX | 13 | — | 13 | 13 |
| CHA | 10 | — | 10 | 10 |
| STR | 8 | — | 8 | 8 |

**Note:** Sage background grants +2/+1 among INT, WIS, CHA. Chosen: INT +2, WIS +1.

Starting HP at L1: 6 (wizard base) + 2 (CON mod) = **8 HP**

---

## Origin Feat (from Human lineage)

**Alert** — Initiative bonus equal to proficiency bonus. Cannot be surprised (no disadvantage on initiative from surprise).

**Rationale:** Wizard wants to cast Shield and Counterspell reactively. High initiative means acting before enemies, reserving reactions for defense. Alert is superior to Magic Initiate for Varian since Sage background already grants Magic Initiate Wizard.

---

## Background: Sage (2024)

**Background Ability Scores:** INT, WIS, CHA (grants +2/+1 OR three +1s)
**Chosen allocation:** INT +2, WIS +1

**Origin Feat (Sage grant):** Magic Initiate (Wizard)
- Learn 2 wizard cantrips and 1 wizard 1st-level spell
- 1st-level spell can be cast 1/long rest without a slot, OR using an existing wizard spell slot
- **Cantrips chosen:** Minor Illusion, Message
- **1st-level spell:** Find Familiar (ritual; can also be cast via slot normally as wizard)

**Skill Proficiencies (Sage):** Arcana, History
**Tool Proficiency:** Calligrapher's Supplies
**Starting Equipment (Sage):** Quarterstaff, Robe, Component Pouch (or Arcane Focus), Spellbook, Dagger, 8 GP (or 50 GP alternative)

---

## Wizard Class Features (2024)

- **Spellcasting** (INT-based; prepared from spellbook at start of day, equal to level + INT mod)
- **Arcane Recovery** (level 1; on short rest once per day, recover spell slots totaling half wizard level rounded up; no slot above 5th)
- **Ritual Adept** (level 1; can cast any wizard spell with Ritual tag as ritual without preparing; no slot expended, +10 min casting time)
- **Scholar** at level 2 (Expertise in one INT-based skill; chosen: **Arcana**)
- **Subclass at level 3** (Evoker)
- **Cantrip Formulas** at level 4 (gain additional cantrip; bonus from level 4 wizard feature)
- **Memorize Spell** (level 5 — changed from 2014; swap one prepared spell between battles during short rest)
- **Cantrip Formulas** at level 10 (another cantrip gained)
- **Spell Mastery** at level 18 (choose one 1st-level and one 2nd-level spell from prepared; cast at base level without slot at will)
- **Signature Spells** at level 20 (choose two 3rd-level spells from spellbook; always prepared, cast each once per short rest without slot)

---

## Spellbook Growth

- Start: 6 spells at L1
- Gain 2 new spells per wizard level thereafter (via free level-up copying)
- Can copy more from scrolls/other spellbooks for time + GP cost (irrelevant for sim)

---

## Level-by-Level Progression

### Tier 1 (Levels 1–4)

**Level 1**
- Class: Spellcasting, Ritual Adept, Arcane Recovery
- Origin feat: Alert
- Background feat: Magic Initiate (Wizard)
- Cantrips known (3): Fire Bolt, Ray of Frost, Mage Hand
  - + Minor Illusion, Message from MI = 5 total
- Spellbook (6 wizard spells): Shield, Mage Armor, Magic Missile, Detect Magic, Sleep, Chromatic Orb
- Spells prepared (4): Shield, Mage Armor, Magic Missile, Sleep
- HP: 8
- AC: 10 + 1 (DEX) = 11 base; with Mage Armor: **14 AC**
- Spell save DC: 8 + 2 (prof) + 3 (INT 17) = **13**
- Spell attack: +2 + 3 = **+5**

**Level 2**
- Scholar: Expertise in Arcana (proficiency doubles)
- Spellbook (+2): add Burning Hands, Feather Fall
- Spells prepared (5)
- HP: 14

**Level 3**
- Subclass: Evoker
  - **Evocation Savant**: Whenever you reach a wizard level, you can add 1 Evocation spell of level equal to new slot level to spellbook for free
  - **Potent Cantrip**: When a target succeeds on save vs a wizard cantrip, they take half the cantrip's damage on success (if it dealt damage)
- 2nd-level spell slots unlocked
- Spellbook (+2 normal + 1 Evocation Savant free): Scorching Ray (evoc, free), Misty Step, Web
  - Actually Evocation Savant grants 1 free evocation spell added to spellbook per wizard level; at L3, that means Scorching Ray free. Plus 2 normal level-up spells: Misty Step, Web
- Spells prepared (6)
- HP: 20

**Level 4**
- ASI: **War Caster** feat (advantage on concentration saves; cast spells with hands occupied; cast spell as opportunity attack)
- Cantrip Formulas: gain 1 additional cantrip (total 6 including MI)
  - New cantrip: Mind Sliver
- Spellbook (+2 + 1 Evocation Savant): Shatter (evoc free), Aid, Invisibility
  - **Wait: Aid is a cleric spell.** Replacement: Mirror Image, Dragon's Breath
- Spells prepared (7)
- HP: 26

### Tier 2 (Levels 5–10)

**Level 5**
- 3rd-level spell slots unlocked
- Spellbook (+2 + 1 Evocation Savant): Fireball (evoc free), Counterspell, Haste
- Spells prepared (8): add Fireball, Counterspell, Fly/Haste
  - Actually Wizard prepares spells equal to wizard level + INT mod. At L5 with INT 17, that's 5 + 3 = 8 prepared
- HP: 32
- Memorize Spell feature (swap spells between short rests)
- **Equipment:** Wand of the War Mage +1 (uncommon) — +1 to spell attack rolls; ignore half cover

**Level 6**
- **Sculpt Spells** (Evoker): When cast Evocation spell affecting an area, choose number of creatures equal to 1 + spell level; those automatically succeed on saves and take no damage
- Spellbook (+2 + 1 Evocation Savant): Hypnotic Pattern, Slow, Flame Strike? (not wizard) → Replace: Lightning Bolt (evoc free)
- Spells prepared (9)
- HP: 38

**Level 7**
- 4th-level spell slots unlocked
- Spellbook (+2 + 1 Evocation Savant): Ice Storm (evoc free), Polymorph, Banishment
- Spells prepared (10)
- HP: 44
- **Equipment:** Cloak of Protection (uncommon) — +1 AC, +1 saves
- AC: 14 (Mage Armor) + 1 (Cloak) = **15**

**Level 8**
- ASI: **+2 INT (17 → 19)** (can't exceed 20 in one ASI, so technically +1 capped; correction: +2 takes it to 19, then one more ASI needed for 20)
  - **Corrected: +2 INT takes 17 → 19. Need one more +1 for 20.**
  - Alternative: Skip second +2 INT and take Resilient CON earlier
  - **Final: +2 INT takes 17→19 at L8**
- Spellbook (+2 + 1 Evocation Savant): Wall of Fire (evoc free), Dimension Door, Greater Invisibility
- Spells prepared (11): include Polymorph, Greater Invisibility
- HP: 50
- Spell save DC: 8 + 3 (prof) + 4 (INT 19) = **15**; wand gives +1 to attack
- **Equipment:** Pearl of Power (uncommon) — recover one expended slot of 3rd level or lower, 1/day

**Level 9**
- 5th-level spell slots unlocked
- Spellbook (+2 + 1 Evocation Savant): Cone of Cold (evoc free), Wall of Force, Telekinesis
- Spells prepared (12): add Wall of Force, Cone of Cold
- HP: 56

**Level 10**
- **Empowered Evocation** (Evoker): Add INT modifier to one damage roll per Evocation cantrip or spell you cast
- Cantrip Formulas: gain 1 more cantrip (total 7)
  - New cantrip: Toll the Dead
- Spellbook (+2 + 1 Evocation Savant): Bigby's Hand (evoc? — arcane evocation spell in 2024), Animate Objects, Seeming
- Spells prepared (13)
- HP: 62
- **Equipment:** Ring of Protection (rare) — +1 AC, +1 saves (stacks with Cloak)
- AC: 14 + 1 (Cloak) + 1 (Ring) = **16**

### Tier 3 (Levels 11–15)

**Level 11**
- 6th-level spell slots unlocked
- Spellbook (+2 + 1 Evocation Savant): Chain Lightning (evoc free), Disintegrate, Globe of Invulnerability
- Spells prepared (14): add Chain Lightning, Disintegrate
- HP: 68

**Level 12**
- ASI: **+1 INT (19→20), +1 CON (14→15)** OR **Resilient (CON)** feat
  - **Chosen: Resilient (CON)** — +1 CON (14→15), proficiency in CON saves. Critical for concentration combined with War Caster
- Wait — we need INT 20 for the +5 mod. Let's reconsider.
  - Actually: Better to take a half-ASI feat. At L12, take: **+1 INT (19→20), +1 CON (14→15)** via straight ASI, so INT hits 20. Then at L16, take Resilient CON.
  - **Revised: L12 ASI +1 INT, +1 CON (INT now 20, CON 15). L16 Resilient CON.**
- INT hits 20: spell save DC = 8 + 4 prof + 5 INT = **17**
- Spellbook (+2 + 1 Evocation Savant): Fire Shield (evoc free? — yes), True Seeing, Contingency
- Spells prepared (15)
- HP: 76

**Level 13**
- 7th-level spell slots unlocked
- Spellbook (+2 + 1 Evocation Savant): Delayed Blast Fireball (evoc free), Teleport, Finger of Death
- Spells prepared (15)
- HP: 83
- **Equipment:** Staff of Power (very rare) — +2 weapon, +2 AC, +2 spell save DC, absorb spells as charges, cast Cone of Cold/Fireball/etc from charges
- AC now: 14 (Mage Armor) + 1 (Cloak) + 1 (Ring) + 2 (Staff) = **18**
- Spell save DC now: 17 + 2 (Staff) = **19**

**Level 14**
- **Overchannel** (Evoker): Once per long rest, when casting a spell of 1st-5th level that deals damage, deal maximum damage. Can use again but take 5×(spell level) necrotic to self per successive use before long rest
- Spellbook (+2 + 1 Evocation Savant): Prismatic Spray (evoc free? — possibly), Forcecage, Plane Shift
- Spells prepared (15)
- HP: 91

**Level 15**
- 8th-level spell slots unlocked
- Spellbook (+2 + 1 Evocation Savant): Sunburst (evoc free), Maze, Mind Blank
- Spells prepared (16)
- HP: 99

### Tier 4 (Levels 16–20)

**Level 16**
- ASI: **Resilient (CON)** — +1 CON (15→16), proficiency in CON saves (combined with War Caster = advantage + proficiency for concentration)
- Spellbook (+2 + 1 Evocation Savant): Incendiary Cloud (evoc free), Dominate Monster, Feeblemind
- Spells prepared (17)
- HP: 107

**Level 17**
- 9th-level spell slots unlocked
- Spellbook (+2 + 1 Evocation Savant): Meteor Swarm (evoc free), Wish, Shapechange
- Spells prepared (18)
- HP: 115
- **Equipment:** Robe of the Archmagi (legendary) — sets base AC to 15 + DEX mod (replaces Mage Armor); +2 spell save DC; advantage on saves vs. spells; spell resistance
- AC: 15 (Robe) + 1 (DEX) + 1 (Cloak) + 1 (Ring) + 2 (Staff) = **20**
- Spell save DC: 17 + 2 (Staff) + 2 (Robe) = **21**

**Level 18**
- **Spell Mastery**: Choose one 1st-level and one 2nd-level prepared spell. Cast them at base level without spell slots as often as desired.
- Chosen: **Shield** (1st) and **Misty Step** (2nd)
- Spellbook (+2 + 1 Evocation Savant): Invulnerability (evoc free), Time Stop, Power Word Stun
- Spells prepared (18)
- HP: 123

**Level 19**
- Epic Boon: **Boon of Spell Recall** — +1 INT (20→21, Epic Boon breaks 20 cap, can reach 30)
  - Once per long rest, cast a prepared spell of 1st-4th level without expending a slot (bonus action to select; can be done again after short rest)
- Spellbook (+2 + 1 Evocation Savant): Gate, Foresight, Wail of the Banshee (evoc? unclear)
- Spells prepared (19)
- HP: 131

**Level 20**
- **Signature Spells**: Choose two 3rd-level spells from spellbook. Always prepared (don't count against prepared limit). Can cast each once per short rest without a spell slot.
- Chosen: **Fireball** and **Counterspell**
- Spellbook (+2 + 1 Evocation Savant): Prismatic Wall (evoc), Weird
- Spells prepared (20)
- HP: 139
- **Equipment:** Staff of the Magi (legendary) — replaces Staff of Power; spell absorption with conversion to wizard spell slots; multiple spell options at will; retributive strike for massive damage

---

## Signature Spell Loadouts by Tier

### Tier 1 (Levels 1–4)
**Combat cantrips:** Fire Bolt, Ray of Frost (speed reduction)
**Combat spells:** Magic Missile, Scorching Ray (L3+), Burning Hands
**Control:** Sleep, Web
**Defense:** Shield (reaction), Mage Armor (hour+ buff)
**Utility:** Detect Magic, Feather Fall, Find Familiar (via MI free 1/long rest)

### Tier 2 (Levels 5–10)
**Primary nuke:** Fireball (Sculpt Spells allows excluding allies), Cone of Cold at L9
**Control:** Web, Hypnotic Pattern, Slow, Wall of Fire
**Battlefield reshape:** Wall of Force (L9), Misty Step (escape)
**Counter/defense:** Counterspell, Shield, Globe of Invulnerability (L11+)
**Buffs:** Haste (party), Fly, Greater Invisibility (self)
**Sculpt Spells:** Critical at L6+; lets Fireball/Cone of Cold/Wall of Fire include party safely

### Tier 3 (Levels 11–15)
**Nukes:** Chain Lightning, Disintegrate, Fireball upcast
**Control:** Forcecage, Wall of Force, Hypnotic Pattern upcast
**Overchannel combo:** Max-damage Fireball (or other evocation L1-5) once per long rest
**Counter stack:** Counterspell + Shield reactions
**Utility:** Teleport, Plane Shift, True Seeing

### Tier 4 (Levels 16–20)
**Capstone damage:** Meteor Swarm, Power Word Stun combo, Wish
**Action economy:** Time Stop (multi-round setup), Foresight (advantage on attacks/saves for 8h)
**Save-or-die:** Power Word Stun, Feeblemind, Dominate Monster
**Defense:** Mind Blank, Foresight, Globe of Invulnerability, Contingency
**Free casting:** Shield + Misty Step at will (Spell Mastery), Fireball + Counterspell 1/short rest (Signature)

---

## Magic Item Summary

| Level | Item | Rarity |
|-------|------|--------|
| 5 | Wand of the War Mage +1 | Uncommon |
| 7 | Cloak of Protection | Uncommon |
| 8 | Pearl of Power | Uncommon |
| 10 | Ring of Protection | Rare |
| 13 | Staff of Power | Very Rare |
| 17 | Robe of the Archmagi | Legendary |
| 20 | Staff of the Magi | Legendary |

---

## AC Progression

| Level | Base (Mage Armor or Robe) | Cloak | Ring | Staff | Total AC |
|-------|---------------------------|-------|------|-------|----------|
| 1-6 | 13+1 DEX (Mage Armor) | — | — | — | 14 |
| 7-9 | 14 | +1 | — | — | 15 |
| 10-12 | 14 | +1 | +1 | — | 16 |
| 13-16 | 14 | +1 | +1 | +2 Staff | 18 |
| 17-19 | 16+1 DEX (Robe, replaces MA) | +1 | +1 | +2 | 21 |
| 20 | 16+1 DEX (Robe) | +1 | +1 | Staff of the Magi (+2 as spellcasting focus, no direct AC) | 19-20 |

---

## Simulation Notes

**Primary combat pattern:**
- Opening: Cast highest-value AoE or control spell (Fireball with Sculpt Spells, Web, Hypnotic Pattern, Hold Person)
- Middle rounds: Maintain concentration; cantrips for damage (Fire Bolt + Mind Sliver combo)
- Emergency: Misty Step out of melee, Shield to block fatal hit, Counterspell to stop enemy spell

**Concentration management:** War Caster (L4) + Resilient CON (L16) gives advantage + proficiency for concentration saves. Most reliable concentration maintainer in the party.

**Empowered Evocation combo (L10+):** Add INT mod to one damage roll of an evocation spell. Stacks with Overchannel's max damage (L14+) for massive single-target nukes.

**Key weaknesses:** Low HP (d6 hit die, no Tough), depends on Mage Armor/Robe for AC, squishy in melee, concentration break from big hits.

**Behavior AI priorities:**
1. If enemies clustered (3+) → Fireball with Sculpt Spells excluding allies
2. If single strong enemy → Control spell (Hypnotic Pattern, Hold Monster, Polymorph, Maze at L15+)
3. If enemy casts dangerous spell (3rd+) → Counterspell reaction
4. If hit would drop below 50% HP → Shield reaction
5. If threatened in melee → Misty Step bonus action
6. Maintain highest-value concentration spell; don't break for flavor
7. Use Arcane Recovery during short rest to refresh mid-day
