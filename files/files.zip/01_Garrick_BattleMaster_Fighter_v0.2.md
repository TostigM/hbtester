# Garrick Ironward — Standard Party Member 1 (CORRECTED v0.2)
## Human Battle Master Fighter (Defense Fighting Style + Shield)

**Corrections from v0.1:**
- Battle Master subclass features verified: levels 3, 7, 10, 15, 18 (not the levels I had previously)
- Know Your Enemy: now a Bonus Action (instant), not 1-minute observation; reveals only Immunities/Resistances/Vulnerabilities; 1/long rest; can spend superiority die to restore
- Student of War: grants 1 tool proficiency AND 1 skill proficiency (I had previously had just tool)
- Superiority Dice: 4 at L3, 5 at L7, 6 at L15 (I had incorrectly said increase at L10)
- Die size upgrades: d10 at L10, d12 at L18 (not L15)
- Relentless at L15: recover 1 superiority die at initiative if out (I had confused this feature)
- Maneuvers learned: +2 at levels 3, 7, 10, 15 (I had that right)
- Ultimate Combat Superiority (L18): d12 die size upgrade

---

## Core Identity

**Species:** Human
**Class:** Fighter (Battle Master subclass at level 3)
**Background:** Soldier
**Alignment:** Lawful Neutral (flavor only)
**Role in Party:** Primary tank, frontline melee damage, battlefield control, priority target marker

---

## Ability Scores (Standard Array + Background ASI, Final)

| Ability | Base | Background ASI | Level 1 | Post-ASI Peak |
|---------|------|----------------|---------|---------------|
| STR | 15 | +2 (Soldier grants STR+DEX+CON choice) | **17** | **20** (at level 8 ASI) |
| CON | 14 | +1 | **15** | **16** (at level 14 feat Tough; OR Resilient CON at L16) |
| DEX | 13 | — | 13 | 13 |
| WIS | 12 | — | 12 | 13 (at L4 Resilient WIS) |
| INT | 10 | — | 10 | 10 |
| CHA | 8 | — | 8 | 8 |

**Note:** 2024 rules: Backgrounds grant ability score increases, NOT species. Human no longer grants ability score increases. Soldier background grants +2/+1 distributed among STR, DEX, CON.

**Allocation:** STR +2, CON +1 (focused martial build)

Starting HP at L1: 10 (base) + 2 (CON mod) + 2 (Tough feat from Human origin) = **14 HP**

---

## Origin Feat (from Human lineage)

**Tough** — HP maximum increases by 2 * character level when feat gained; +2 per level thereafter.

---

## Background: Soldier (2024)

**Background Ability Scores:** STR, DEX, CON (grants +2/+1 OR three +1s among these)
**Chosen allocation:** STR +2, CON +1

**Origin Feat (Soldier grant):** Savage Attacker
- Once per turn, reroll one weapon damage roll and use the higher result. Applies to both melee AND ranged weapons in 2024 (changed from 2014 which was melee only).

**Skill Proficiencies (Soldier):** Athletics, Intimidation
**Tool Proficiency:** Gaming Set
**Starting Equipment (Soldier):** Spear, Shortbow (20 arrows), Gaming Set, Healer's Kit, Travelers Clothes, 14 GP (OR 50 GP alternative)

---

## Fighter Class Features

**Level 1:**
- Fighting Style (feat): **Defense** (+1 AC while wearing armor)
- Second Wind: 2 uses, bonus action, heal 1d10 + fighter level. Regain 1 on short rest, all on long rest.
- Weapon Mastery: 3 weapons chosen: **Longsword (Sap), Longbow (Slow), Handaxe (Vex)**

**Level 2:**
- Action Surge (1 use per short rest)
- Tactical Mind: Spend Second Wind die to add to failed ability check

**Level 3:** Subclass chosen: **Battle Master**
- Combat Superiority: 4 superiority dice (d8s), 3 maneuvers known
- Student of War: +1 tool proficiency (Smith's Tools) + 1 skill from Fighter list (chosen: **Perception**)

**Level 4:**
- ASI (general feat): **Resilient (WIS)** — +1 WIS (to 13), proficiency in WIS saves

**Level 5:**
- Extra Attack (1): 2 attacks per Attack action
- Tactical Shift: When using Second Wind, can move up to half speed without provoking opportunity attacks

**Level 6:** Fighter bonus ASI
- **ASI +2 STR (16→18)**

**Level 7:**
- Battle Master: Know Your Enemy (bonus action reveals immunities/resistances/vulnerabilities, 1/long rest, restore with superiority die)
- Superiority Dice: 5 total
- Maneuvers: 5 total (add 2)

**Level 8:**
- ASI: **+2 STR (18→20)** — primary stat maxed

**Level 9:**
- Indomitable (1 use per long rest, reroll failed save)
- Tactical Master: While Second Wind not expended, no opportunity attacks against you

**Level 10:**
- Battle Master: Improved Combat Superiority (dice upgrade to **d10**)
- Maneuvers: 7 total (add 2)

**Level 11:**
- Two Extra Attacks: 3 attacks per Attack action

**Level 12:**
- ASI: **Alert** feat (initiative bonus equal to proficiency bonus)

**Level 13:**
- Studied Attacks: On miss, next attack vs same target has advantage (until end of next turn)
- Indomitable: 2 uses

**Level 14:** Fighter bonus ASI
- **Tough** feat — retroactive HP boost (2 × level = 28 HP added immediately, +2 per level gained thereafter)
- **WAIT — already have Tough from Human origin.** Replace with: **Lucky** (3 luck points per long rest)

**Level 15:**
- Battle Master: Relentless — at initiative, if out of superiority dice, regain 1 (d8); refreshes each encounter
- Superiority Dice: 6 total
- Maneuvers: 9 total (add 2)

**Level 16:**
- ASI: **Resilient (CON)** — +1 CON (to 16; save prof redundant but stat helps HP/concentration-equivalent)

**Level 17:**
- Action Surge: 2 uses per short rest
- Indomitable: 3 uses per long rest

**Level 18:**
- Battle Master: Ultimate Combat Superiority (dice upgrade to **d12**)
- Studied Attacks improved: Can use on ANY attack, not just after miss

**Level 19:**
- Epic Boon: **Boon of Combat Prowess** — once per turn, if you miss with an attack, you can hit instead. +1 STR (can exceed 20, max 30)
- STR becomes 21

**Level 20:**
- Three Extra Attacks: 4 attacks per Attack action

---

## Maneuvers Selected (by Level)

**Level 3 (3 known):** Trip Attack, Precision Attack, Menacing Attack
**Level 7 (5 known):** Add Riposte, Goading Attack
**Level 10 (7 known):** Add Commander's Strike, Parry
**Level 15 (9 known):** Add Disarming Attack, Evasive Footwork

---

## Magic Item Progression (Per 2024 DMG)

| Level | Item | Rarity | Notes |
|-------|------|--------|-------|
| 4 | +1 Longsword | Uncommon | Primary weapon upgrade |
| 6 | +1 Shield | Uncommon | AC +1 |
| 8 | +1 Plate Armor | Rare | AC = 18 (plate) + 2 (+1 shield) + 1 (Defense) + 1 (+1 armor) = **22** |
| 11 | Flame Tongue Longsword | Rare | Replaces +1 Longsword; adds 2d6 fire on hit |
| 13 | +2 Plate Armor | Very Rare | AC = 18 + 2 + 1 + 2 = **23** (with +1 shield) |
| 14 | Cloak of Protection | Uncommon | +1 AC, +1 saves (AC now **24**) |
| 16 | +2 Shield | Rare | AC now **25** |
| 18 | +2 Flame Tongue Longsword | Very Rare | Custom upgrade |
| 20 | +3 Plate Armor | Legendary | AC = 18 + 2 (+2 shield) + 1 (Defense) + 3 (+3 plate) + 1 (Cloak) = **25** |

---

## HP Progression

Using average HP per level (d10 = 6 average + CON mod + 2 Tough):

| Level | Base+CON | Tough | Cumulative HP |
|-------|----------|-------|---------------|
| 1 | 10+2 | +2 | 14 |
| 4 | 4×8 | +8 | 44 |
| 8 | 8×8 | +16 | 80 |
| 12 | 12×8+2(CON bump L16 retro) | +24 | 120 |
| 16 | adjusted for CON 16 | +32 | 160+ |
| 20 | final | +40 | ~200 |

---

## AC Progression

| Level | Armor | Shield | Fighting Style | Item Bonus | Cloak | Total AC |
|-------|-------|--------|----------------|-----------|-------|----------|
| 1-3 | Chain Mail (16) | +2 | +1 (Defense) | — | — | **19** |
| 4-5 | Chain Mail (16) | +2 | +1 | — | — | **19** |
| 6-7 | Chain Mail (16) | +1 Shield (+3) | +1 | — | — | **20** |
| 8-10 | +1 Plate (18) | +1 Shield (+3) | +1 | +1 armor | — | **23** |
| 11-12 | +1 Plate | +1 Shield | +1 | +1 | — | **23** |
| 13 | +2 Plate (18+2) | +1 Shield | +1 | +2 | — | **24** |
| 14-15 | +2 Plate | +1 Shield | +1 | +2 | +1 | **25** |
| 16-19 | +2 Plate | +2 Shield (+4) | +1 | +2 | +1 | **26** |
| 20 | +3 Plate (18+3) | +2 Shield | +1 | +3 | +1 | **27** |

---

## Simulation Notes

**Primary combat pattern:**
- Engage melee threats
- Apply Sap mastery on priority targets (disadvantage on their next attack)
- Use Trip Attack on spellcasters and large melee threats
- Reserve Riposte for reactive damage

**Emergency buttons:** Action Surge, Second Wind, Indomitable

**Key weaknesses:** Low INT/CHA saves (WIS mitigated by Resilient). Limited ranged capability (Longbow is backup).

**Behavior AI priorities:**
1. Engage highest-threat melee enemy
2. Trip Attack on spellcasters or high-damage dealers
3. Sap mastery on primary attacker each turn
4. Action Surge on boss encounters or focus-fire moments
5. Second Wind when below 50% HP
