# Monster Content Schema — Proposal v0.2 (CORRECTED)

**Corrections from v0.1:**
- Legendary actions restructured: each is now SINGLE USE until refresh (no more 3-point pool where actions cost 2-3 points). Refresh at start of monster's turn.
- Stat block layout revised to match 2025 MM format: ability scores in unified table with modifier AND save together; initiative near AC
- Added "Gear" field (new 2025 MM section listing weapons/armor the creature carries)
- Spellcasting now default format: at-will spells and per-day spells directly in stat block (not spell slots, except for some casters)
- Lair mechanics: monsters in lair gain BONUS legendary resistance uses and BONUS legendary action uses; lair actions still exist but are subsidiary to these bonuses
- Added "Habitat and Treasure" narrative section (not mechanical but part of 2025 MM layout)
- Multiattack format: often consolidates into a single "Rend" or similar attack for simpler runtime

---

## Purpose

Monsters are the opposition in combat encounters. This schema models 2024/2025 Monster Manual stat blocks. Monster testing evaluates homebrew monsters against the standard party at character level equal to CR, CR ± 2, and CR ± 4 (per Liege's direction).

---

## Design Principles

Same as prior schemas, plus two specific to monsters:

**2025 Monster Manual compliance.** Schema reflects the new stat block format, not 2014 MM. Some structural changes are significant (legendary action economy, spellcasting format).

**Encounter-centric, not creature-centric.** Engine cares about in-combat mechanics. Narrative flavor (society, lore, habitat text) is stored but ignored during simulation.

---

## Top-Level Monster Structure (2025 MM Format)

```yaml
schema_version: "0.2"
content_type: "monster"
id: "adult_red_dragon"
display_name: "Adult Red Dragon"
source: "MM_2025"
version: "2024"
author: "Wizards of the Coast"
flavor_text: "A colossal winged reptile..."

# Classification
creature_type: "dragon"                # aberration, beast, celestial, construct, dragon, elemental, fey, fiend, giant, humanoid, monstrosity, ooze, plant, undead
size: "huge"                           # tiny, small, medium, large, huge, gargantuan
subtype: "chromatic"                   # e.g., "chromatic" for chromatic dragons
alignment: "chaotic_evil"              # narrative only
habitat: ["mountain", "volcanic"]      # 2025 MM new field; ties to DMG treasure themes
treasure_themes: ["arcana", "relics"]  # 2025 MM new field

# Core combat stats (2025 format: initiative near AC)
ac: 19
ac_source: "natural_armor"
initiative: "+4"                        # now explicitly listed
initiative_flat: 14                     # static alternative for quick combat resolution
hp:
  average: 256
  formula: "19d12 + 133"
hit_dice: "19d12"

# Speed
speed:
  walk: 40
  fly: 80
  swim: 0
  climb: 40
  burrow: 0

# Ability scores (2025 format: unified table with mod and save in one entry)
abilities:
  STR: { score: 27, modifier: 8, save_bonus: 8 }
  DEX: { score: 10, modifier: 0, save_bonus: 6 }    # DEX save proficient (prof +6)
  CON: { score: 25, modifier: 7, save_bonus: 13 }   # CON save proficient
  INT: { score: 16, modifier: 3, save_bonus: 3 }
  WIS: { score: 13, modifier: 1, save_bonus: 7 }    # WIS save proficient
  CHA: { score: 21, modifier: 5, save_bonus: 11 }   # CHA save proficient

# Skills (bonus is explicit total, not derived)
skills:
  - skill: "perception"
    bonus: 13
  - skill: "stealth"
    bonus: 6

# Senses
senses:
  darkvision: 120
  blindsight: 60
  tremorsense: 0
  truesight: 0
  passive_perception: 23

# Languages
languages: ["common", "draconic"]

# Challenge Rating and XP
challenge_rating: 17
proficiency_bonus: 6
xp_value: 18000
xp_in_lair: 20000                       # 2025 MM: additional XP for defeating in lair

# Damage/condition modifiers (2025: grouped immunities, resistances, vulnerabilities together)
damage_resistances: []
damage_immunities: ["fire"]
damage_vulnerabilities: []
condition_immunities: []

# 2025 NEW FIELD: Gear
gear: ["mountain_treasure_hoard"]       # items monster typically has; doesn't affect combat directly but provides narrative hook

# Mechanical blocks
traits: [ ... ]                     # passive always-on features
actions: [ ... ]                    # monster's turn actions
bonus_actions: [ ... ]              # optional
reactions: [ ... ]                  # optional
legendary_actions: { ... }          # 2025 format: single-use per action
legendary_resistance: { ... }       # if applicable
lair_bonuses: { ... }               # NEW 2025 convention: extra LA/LR uses in lair
lair_actions: [ ... ]               # some monsters still have classic lair actions
regional_effects: [ ... ]           # descriptive; not mechanically simulated

# Spellcasting (2025 format: at-will and per-day lists, not spell slots)
spellcasting: { ... }

# Behavior AI hints
behavior_hints: { ... }
```

---

## Traits (unchanged from v0.1)

Passive always-on features. Use feature_type vocabulary.

Example: Fire Immunity, Legendary Resistance trait, etc.

```yaml
traits:
  - id: "fire_immunity"
    display_name: "Fire Immunity"
    feature_type: "damage_immunity"
    body:
      damage_type: "fire"

  - id: "legendary_resistance"
    display_name: "Legendary Resistance"
    feature_type: "legendary_resistance"
    body:
      uses_per_day_base: 3
      uses_per_day_in_lair: 4      # 2025: extra use in lair
      effect: "choose_to_succeed_on_failed_save"
```

---

## Actions (2025 Consolidated Format)

Actions on monster's turn. 2025 MM often consolidates multiple attacks into a single "Rend" action rather than separate bite/claw/tail.

### Multiattack (simplified in 2025)

```yaml
actions:
  - id: "rend"                         # 2025: often consolidated
    display_name: "Rend"
    activation: "action"
    effect:
      type: "multi_attack_consolidated"
      attack_count: 3                  # dragon makes 3 attacks as one Rend action
      per_attack:
        attack_bonus: 14
        reach: 10
        damage:
          - die: "2d10"
            modifier: 8
            damage_type: "piercing"
      total_damage_average: 57         # for quick combat resolution
```

### Breath Weapon (recharge, 2025 format)

```yaml
  - id: "fire_breath"
    display_name: "Fire Breath (Recharge 5-6)"
    activation: "action"
    recharge: "5_6"
    effect:
      type: "aoe_save_half"
      shape: "cone"
      size: 60
      damage: "18d6"
      damage_type: "fire"
      save: "DEX"
      dc: 21
```

### Spellcasting Action (2025 spellbook format, NOT slot-based)

```yaml
  - id: "spellcasting"
    display_name: "Spellcasting"
    activation: "action"
    effect:
      type: "cast_spell"
      caster_level: 18
      spellcasting_ability: "CHA"
      spell_save_dc: 21
      spell_attack_bonus: 13
      at_will:                          # 2025: at-will list replaces cantrips
        - "detect_magic"
        - "mage_hand"
        - "command"
      per_day:                           # 2025: per-day list replaces slots for monsters
        - spell: "fireball"
          uses_per_day: 3
        - spell: "scrying"
          uses_per_day: 1
```

---

## Legendary Actions (2025 Format — SINGLE USE Per Action)

Critical correction from v0.1: Each legendary action is now single-use until refresh, not pool-based.

```yaml
legendary_actions:
  # 2025 format
  description: "The dragon can take the listed Legendary Actions, using the number of uses shown. It regains all expended uses at the start of its turn."
  uses_available: 3                     # base uses
  uses_in_lair: 4                       # extra use in lair
  
  options:
    - id: "detect"
      display_name: "Detect"
      description: "The dragon makes a Wisdom (Perception) check."
      single_use: true                  # 2025 key change: each action single-use
      effect:
        type: "skill_check"
        skill: "perception"
    
    - id: "tail_attack"
      display_name: "Tail Attack"
      description: "The dragon makes a Tail attack."
      single_use: true
      effect:
        type: "melee_weapon_attack"
        attack_bonus: 14
        reach: 15
        damage:
          - die: "2d8"
            modifier: 8
            damage_type: "bludgeoning"
    
    - id: "pounce"                       # 2025 often renames/replaces Wing Attack
      display_name: "Pounce"
      description: "The dragon moves up to half its flying speed and makes a Claw attack against one creature it passed over."
      single_use: true
      effect:
        type: "movement_plus_attack"
        movement_type: "fly"
        movement_distance: "up_to_40ft"
        attack:
          attack_bonus: 14
          damage:
            - die: "2d6"
              modifier: 8
              damage_type: "slashing"
```

**Key mechanical difference from v0.1:**
- OLD (2014): 3 legendary action points per round; Wing Attack costs 2 points; choose which to spend each time
- NEW (2025): 3 legendary actions per round, each single-use; refresh all at start of monster's turn. Makes bookkeeping simpler.

---

## Legendary Resistance (unchanged, slight enhancement)

```yaml
legendary_resistance:
  uses_per_day_base: 3
  uses_per_day_in_lair: 4               # 2025: often bonus in lair
  effect: "fail_save_then_choose_to_succeed_instead"
  scope: "any_saving_throw"
```

---

## Lair Bonuses (NEW 2025 Convention)

Monsters in their lair gain bonuses beyond just lair actions:

```yaml
lair_bonuses:
  applies_when: "in_lair"
  bonuses:
    - effect: "additional_legendary_resistance_use"
      count: 1
    - effect: "additional_legendary_action_use_per_turn"
      count: 1
```

These are applied automatically when the encounter is in the lair.

---

## Lair Actions (Some Monsters Still Have These)

Many 2025 monsters have replaced lair actions with the "bonuses in lair" model above. Some still use classic lair actions on initiative 20.

```yaml
lair_actions:
  trigger: "initiative_count_20_in_lair"
  options:
    - id: "magma_eruption"
      effect:
        type: "aoe_save_half"
        shape: "sphere_20ft"
        placement: "anywhere_in_lair"
        damage: "7d10"
        damage_type: "fire"
        save: "DEX"
        dc: 15
```

---

## Regional Effects (unchanged)

Narrative effects in the region around a lair. Not mechanically simulated.

---

## Behavior Hints for Monsters

```yaml
behavior_hints:
  intelligence_tier: "high"               # low (animal), medium (humanoid typical), high (cunning), genius
  tactical_preferences:
    - "use_breath_weapon_when_multiple_enemies_in_cone"
    - "target_spellcasters_first_with_frightful_presence"
    - "stay_airborne_when_possible_for_advantage"
    - "use_legendary_actions_defensively_when_bloodied"
  retreat_behavior: "flee_when_at_25_percent_hp_if_intelligent"
  resource_conservation: "aggressive"      # aggressive, moderate, conservative
  combat_role: "solo_boss"                 # solo_boss, elite, skirmisher, soldier, minion
```

---

## Monster Categorization for Testing (Unchanged)

- **solo_boss:** Single high-CR monster (adult dragons, liches). Test at party level = CR, ±2, ±4.
- **elite:** High-CR with minions or in pairs (ogres, giants). Standalone + mixed encounters.
- **skirmisher:** Medium-CR fast attackers (wolves, spectres). Groups of 3-6.
- **soldier:** Medium-CR durable (orcs, hobgoblins, knights). Groups of 3-5.
- **minion:** Low-CR mob (goblins, zombies). Hordes of 8-20+.
- **trap_monster:** Environmental/ambush (mimics, cloakers).

---

## CR-to-Party-Level Mapping (Unchanged)

Test each monster at:
- Character level = CR (balanced)
- CR - 2 (party underleveled; test overkill scenario)
- CR - 4 (party should flee; test danger at gap)
- CR + 2 (party overleveled; test if still challenging)
- CR + 4 (trivial win expected; test monster is indeed underleveled)

Skip levels below 1 or above 20 as appropriate for the CR.

---

## Encounter Composition Variations (Unchanged)

- Solo: 1 monster vs party
- Pair: 2 monsters
- Squad: 3-5 monsters
- Horde: 6+ monsters
- Mixed: test monster as leader with supporting weaker creatures

Each composition tagged for reporting.

---

## Validation Rules Specific to Monsters (2025 Corrected)

1. **All stat fields present** (AC, HP, initiative, speed, abilities, CR).
2. **CR must be valid** (0, 1/8, 1/4, 1/2, 1-30).
3. **Hit dice formula approximately matches HP average.**
4. **Proficiency bonus matches CR per 2024 MM:**
   - CR 0-4: +2
   - CR 5-8: +3
   - CR 9-12: +4
   - CR 13-16: +5
   - CR 17-20: +6
   - CR 21-24: +7
   - CR 25-28: +8
   - CR 29-30: +9
5. **Legendary actions (if present) use single-use format per 2025.**
6. **Lair bonuses valid if monster has "has_lair: true" flag.**
7. **Spellcasting uses at_will/per_day format for 2025 monsters (spell slots reserved for unusual cases).**
8. **Initiative bonus matches DEX mod plus any class/feature bonuses.**
9. **Skill bonuses explicit (not derived) to match 2025 stat block style.**
10. **Damage types on attacks valid.**
11. **Creature type valid.**
12. **Gear field present but does not affect combat (unless flagged).**

---

## Homebrew Monster Additional Checks (Unchanged)

1. **CR calculation sanity:** Check against DMG monster-building guidelines.
2. **Action economy vs CR:** High-CR monsters should have multiattack or multiple action options.
3. **Save DC vs CR:** Should match 8 + proficiency + relevant mod; outliers flagged.
4. **Damage per round vs CR:** Check against DMG DPR ranges.
5. **Legendary resistance presence:** CR 10+ bosses typically have LR.
6. **Spellcasting overreach:** Shouldn't exceed equivalent caster class.

---

## Open Questions for Liege Review

1. **How complex should the "environment" be during monster testing?** Per v0.1 discussion: test both in-lair and standard scenarios. With 2025 bonuses, this matters more than ever. Recommend: test separately and report both.

2. **Do we simulate the "minion support" aspect of lower-CR monsters?** Test solo AND in squad with leader. Recommend: both.

3. **Monster behavior AI complexity.** High-INT monsters play strategically; animal-INT play instinctively. AI needs to handle both. Architecture spec concern.

4. **Legendary resistance as a meta-mechanic.** LR changes caster-vs-boss dynamic. Engine must track LR uses precisely. Flagging.

5. **2025 MM's simplified action blocks (e.g., Rend consolidating attacks):** Engine should handle both consolidated-attack monsters AND monsters that still have separate bite/claw/tail. Schema supports both patterns.

6. **Treasure/gear:** Stored in schema, not simulated. Can be referenced in post-encounter report for narrative flavor.
