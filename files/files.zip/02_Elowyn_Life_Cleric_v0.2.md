# Elowyn Dawnbrook — Standard Party Member 2 (CORRECTED v0.2)
## Human Life Cleric (Divine Order: Thaumaturge)

**Corrections from v0.1:**
- 2024 Life Domain spell list corrected: Aid (lvl 3), Mass Healing Word (lvl 3), Aura of Life (lvl 7), Greater Restoration (lvl 9) are IN; Spiritual Weapon, Beacon of Hope, Guardian of Faith, Raise Dead are OUT of always-prepared list
- Life Domain no longer grants heavy armor (confirmed; was 2014 feature, removed in 2024)
- Disciple of Life and Preserve Life are level 3 features (subclass chosen at L3 in 2024), not earlier
- Preserve Life now targets Bloodied creatures only (2024 change); works on Undead and Constructs (2024 change)
- Blessed Strikes is a BASE CLERIC feature at level 7 (choice of Divine Strike OR Potent Spellcasting), not level 6 subclass feature
- Improved Blessed Strikes at level 14 (boosts whichever you picked at 7)
- Divine Intervention at level 10: cast 5th-level-or-lower cleric spell without slot, 1/long rest (no percentile dice)
- Greater Divine Intervention at level 20: Can cast Wish via Divine Intervention (2d4 long rests until next use)
- Channel Divinity uses scale: 2 uses at level 1, 3 at level 7, 4 at level 18
- Cleric cantrip scaling at levels 4 and 10 (adds one more cantrip; I had that right partially)
- Subclass chosen at level 3, not level 1 (2024 change)
- Ability scores now from background, not species (Human grants no ASI)

---

## Core Identity

**Species:** Human
**Class:** Cleric (Life Domain subclass at level 3)
**Divine Order:** Thaumaturge (selected at level 1)
**Background:** Acolyte
**Alignment:** Lawful Good (flavor)
**Role in Party:** Primary healer, support caster, buffer, utility caster

---

## Ability Scores (Standard Array + Background ASI, Final)

| Ability | Base | Background ASI | Level 1 | Post-ASI Peak |
|---------|------|----------------|---------|---------------|
| WIS | 15 | +2 (Acolyte grants INT+WIS+CHA choice) | **17** | **20** (at level 8) |
| CON | 14 | +1 | **15** | 15 |
| STR | 13 | — | 13 | 13 |
| DEX | 12 | — | 12 | 12 |
| CHA | 10 | — | 10 | 10 |
| INT | 8 | — | 8 | 8 |

**Note:** Acolyte background grants +2/+1 among INT, WIS, CHA. Chosen: WIS+2, CON... wait, CON is not in Acolyte list. Corrected allocation: **WIS+2, CHA+1.** CHA becomes 11 instead.

**CORRECTED ABILITY SCORES:**
| Ability | Base | Background ASI | Level 1 | Post-ASI Peak |
|---------|------|----------------|---------|---------------|
| WIS | 15 | +2 | **17** | **20** (at level 8) |
| CHA | 10 | +1 | **11** | 11 |
| CON | 14 | — | 14 | 14 |
| STR | 13 | — | 13 | 13 |
| DEX | 12 | — | 12 | 12 |
| INT | 8 | — | 8 | 8 |

Starting HP at L1: 8 (cleric base) + 2 (CON mod) + 2 (Tough... wait, not taken) = **10 HP**

**Correction:** Elowyn does NOT have Tough. Human Origin Feat chosen: **Healer**.

Starting HP at L1: 8 + 2 (CON) = **10 HP**

---

## Origin Feat (from Human lineage)

**Healer** — Grants Healer's Kit proficiency; once per short rest as Utilize action, use Healer's Kit to restore 1d6 + 4 + character level HP to a creature. Relevant for a healer character and doesn't consume spell slots.

---

## Background: Acolyte (2024)

**Background Ability Scores:** INT, WIS, CHA (grants +2/+1 OR three +1s)
**Chosen allocation:** WIS +2, CHA +1

**Origin Feat (Acolyte grant):** Magic Initiate (Cleric)
- Learn 2 cleric cantrips and 1 cleric 1st-level spell
- Can cast the 1st-level spell 1/long rest without a slot, OR using a cleric spell slot normally
- **Cantrips chosen:** Light, Spare the Dying
- **1st-level spell:** Detect Magic (ritual; also castable 1/long rest without slot)

**Skill Proficiencies (Acolyte):** Insight, Religion
**Tool Proficiency:** Calligrapher's Supplies
**Starting Equipment:** Book (prayer book), Holy Symbol, Calligrapher's Supplies, Robe, Parchment, small knife, 8 GP (or 50 GP alternative)

---

## Divine Order: Thaumaturge

**Features at level 1:**
- **Bonus Cantrip:** Learn one extra Cleric cantrip (chosen: **Sacred Flame**)
- **Mystic Insight:** Add WIS modifier to Intelligence (Arcana or Religion) checks (minimum +1)

**Proficiencies:** Cleric base only (Light armor, Medium armor, Shields, Simple weapons)
- Thaumaturge does NOT grant heavy armor or martial weapons (Protector order grants those)

**Primary weapon:** Mace (simple weapon) with Shield
- Secondary: Sacred Flame cantrip (ranged damage)

---

## Cleric Class Features (2024)

- **Spellcasting** (WIS-based, prepared caster, prepared spell count from class table)
- **Divine Order** (Thaumaturge, level 1)
- **Channel Divinity** (level 2; 2 uses, recover 1 on short rest, all on long rest; scales to 3 at L7, 4 at L18)
  - Base options: Turn Undead, Divine Spark (heal OR damage 1d8 + WIS at 30 ft; 2d8 at L7, 3d8 at L13, 4d8 at L18)
- **Sear Undead** at level 5 (Turn Undead adds WIS mod d8s of radiant damage to undead that fail save)
- **Blessed Strikes** at level 7 (choice of Divine Strike or Potent Spellcasting)
- **Divine Intervention** at level 10
- **Improved Blessed Strikes** at level 14
- **Greater Divine Intervention** at level 20

---

## Level-by-Level Progression

### Tier 1 (Levels 1–4)

**Level 1**
- Class Features: Spellcasting, Divine Order (Thaumaturge)
- Origin Feat: Healer
- Background Feat: Magic Initiate (Cleric)
- Cantrips known (4): Sacred Flame (Thaumaturge bonus), Guidance, Spare the Dying, Light (from Magic Initiate)
  - Magic Initiate gives 2 cantrips so add: Thaumaturgy, replaces Light duplicate
  - Final: Sacred Flame, Guidance, Thaumaturgy, Spare the Dying, Light (5 total because Magic Initiate stacks)
- Prepared spells (4): Cure Wounds, Healing Word, Bless, Shield of Faith
- AC: 14 (Scale Mail) + 2 (Shield) = **16**
- HP: 10
- Spell save DC: 8 + 2 (prof) + 3 (WIS 17) = **13**

**Level 2**
- Channel Divinity (2 uses): Turn Undead, Divine Spark
- HP: 18
- Spells prepared (5): add Command

**Level 3**
- Subclass features unlock: Life Domain
  - **Disciple of Life**: Healing spells restore additional 2 + spell level HP on turn cast
  - **Preserve Life**: Channel Divinity option; choose Bloodied creatures in 30 ft, distribute 5 × cleric level HP among them; can't heal above half max HP; works on Undead and Constructs
  - **Life Domain Spells** (always prepared at L3): Aid, Bless, Cure Wounds, Lesser Restoration
- 2nd-level spell slots unlocked
- Spells prepared (6): Life Domain 4 always-prepared + 2 normal (example: Spiritual Weapon — still available as regular cleric spell, just not always-prepared for Life; Command)
- HP: 26

**Level 4**
- ASI: **+2 WIS (17 → 19)** (not quite 20 yet; need one more ASI)
- New cantrip (Cantrips column shows bump at L4): add **Toll the Dead**
- Spells prepared (8 total now)
- HP: 34

### Tier 2 (Levels 5–10)

**Level 5**
- 3rd-level spell slots unlocked
- Sear Undead feature (adds WIS mod d8s radiant when Turn Undead)
- Spells prepared (9): add Mass Healing Word (Life Domain at L5), Revivify (Life Domain at L5), Spirit Guardians, Beacon of Hope
- Life Domain Spells at L5 add: **Mass Healing Word, Revivify** (always prepared)
- Sacred Flame scales to 2d8
- HP: 42
- **Equipment:** +1 Mace (uncommon)

**Level 6**
- Channel Divinity: still 2 uses (no bump)
  - *Clarification: 2024 Cleric has 2 CD uses through L6; bumps to 3 at L7 per some sources; verify in actual PHB*
- Spells prepared (10)
- HP: 50

**Level 7**
- Channel Divinity: 3 uses (per verified sources)
- **Blessed Strikes feature choice:** Choose Divine Strike OR Potent Spellcasting
  - For Elowyn: **Potent Spellcasting** (adds WIS mod to Cleric cantrip damage; better for caster-focused build via Thaumaturge)
- 4th-level spell slots unlocked
- Life Domain Spells at L7 add: **Aura of Life, Death Ward** (always prepared)
- Spells prepared (11): add Freedom of Movement, Guardian of Faith
- HP: 58
- **Equipment:** +1 Shield (uncommon) — AC now 17

**Level 8**
- ASI: **+2 WIS (19 → 20)** — primary stat maxed
  - Actually: WIS went from 17 (post-background) to 19 at L4 ASI. L8 ASI: +1 WIS +1 other, OR +2 WIS to 21? Max is 20 via ASI. So +2 WIS: 19→20? No, 19+2=21, capped at 20 by ASI rule. So +1 WIS to 20, +1 other? Actually 2024 allows +2 to one ability score if increasing by ASI feat. So +2 to WIS from 19 would be 21, but capped at 20. So effectively +1 WIS, 1 point "wasted" — OR use ASI on +1 WIS, +1 CON to 15.
  - **Correction: At L4 took +2 WIS taking WIS from 17→19. At L8, WIS is 19. ASI grants +2 to one or +1 to two; can't exceed 20 via ASI. So +1 WIS to 20, +1 CON to 15 (now CON 15).**
- Spells prepared (13)
- HP: 66 (CON now 15 with +2 mod, retroactive-ish; actual HP calculated per level with CON at time)
- **Equipment:** Periapt of Wound Closure (uncommon)

**Level 9**
- 5th-level spell slots unlocked
- Life Domain Spells at L9 add: **Greater Restoration, Mass Cure Wounds** (always prepared)
- Spells prepared (14): add Raise Dead, Flame Strike
- HP: 74

**Level 10**
- **Divine Intervention**: As Magic action, cast any Cleric spell of level 5 or lower without slot or material components. 1/long rest.
- New cantrip added (Cantrips column): pick another (5 total cantrips + MI extras)
- Spells prepared (15)
- HP: 82
- **Equipment:** +1 Half Plate (rare) — AC: 15 (Half Plate) + 2 (+1 shield) + 1 DEX (limited by armor) + 1 (+1 enhancement) = **18**
  - Corrected: Half Plate gives 15 + DEX (max 2) = 17. +1 shield = 19. +1 armor = 20.
  - Wait, +1 shield was already counted at L7. So at L10: +1 Half Plate replaces non-magical Scale Mail. New AC: 15 (Half Plate) + 2 DEX + 2 (+1 Shield from L7) + 1 (armor enhancement) = 20

### Tier 3 (Levels 11–15)

**Level 11**
- 6th-level spell slots unlocked
- Spells prepared (16): add Heal, Heroes' Feast
- HP: 90
- **Equipment:** Staff of Healing (rare)

**Level 12**
- ASI: **War Caster** feat (advantage on concentration saves; cast spells with hands full; cast spell as opportunity attack)
- Spells prepared (16)
- HP: 98

**Level 13**
- Divine Spark scales to 3d8
- 7th-level spell slots unlocked
- Spells prepared (17): add Plane Shift, Resurrection, Regenerate
- HP: 106
- **Equipment:** Amulet of Health (rare) — CON becomes 19 minimum; HP recalculated with new CON modifier

**Level 14**
- **Improved Blessed Strikes**: Potent Spellcasting upgrades so that when you deal damage with a cleric cantrip, you can grant temp HP = 2 × WIS mod to yourself or creature within 60 ft (this is the L14 upgrade per 2024 PHB per verified sources)
- Spells prepared (17)
- HP: 114 (retroactive with CON 19)

**Level 15**
- 8th-level spell slots unlocked
- Spells prepared (18): add Holy Aura, Sunburst (or Power Word Fortify — new 2024 spell)
- HP: 122
- **Equipment:** Cloak of Protection (uncommon) — +1 AC, +1 saves

### Tier 4 (Levels 16–20)

**Level 16**
- ASI: **Inspiring Leader** feat — 10-min speech grants temp HP = CHA + level to up to 6 allies. But Elowyn's CHA is only 11 (+0 mod). Not great.
  - **Better choice: Resilient (DEX)** — +1 DEX (to 13), DEX save proficiency (helpful against AoE spells)
- Spells prepared (18)
- HP: 130

**Level 17**
- Life Domain: **Supreme Healing** — when you would roll dice to restore HP with a spell or Channel Divinity, don't roll; use max values (e.g., Cure Wounds 2d8 becomes 16 + WIS mod automatically)
- 9th-level spell slots unlocked
- Spells prepared (19): add Mass Heal, True Resurrection
- HP: 138
- **Equipment:** Tome of Understanding (very rare) — +2 WIS to 22 (exceeds 20 cap; legal with Tome)

**Level 18**
- Channel Divinity: 4 uses per short rest (scaling max per 2024)
- Divine Spark scales to 4d8
- Spells prepared (19)
- HP: 146

**Level 19**
- Epic Boon: **Boon of Fate** — +1 WIS (stacks beyond 22 via Epic Boon; WIS 23)
  - Once per Short/Long Rest or on rolling initiative: when another creature within 60 ft fails or succeeds a D20 test, roll 2d4 and add or subtract from the roll
- Spells prepared (19)
- HP: 154

**Level 20**
- **Greater Divine Intervention**: When using Divine Intervention, can choose Wish spell. Can't use Divine Intervention again until 2d4 long rests finish.
- Spells prepared (20)
- HP: 162

---

## Signature Spell Loadouts by Tier

### Tier 1 (Levels 1–4) Spell Priority
- **Combat:** Sacred Flame (cantrip damage), Bless (party buff)
- **Healing:** Cure Wounds, Healing Word (bonus action revive), Preserve Life (L3+)
- **Utility:** Guidance, Detect Magic (via MI free cast), Silence

### Tier 2 (Levels 5–10) Spell Priority
- **Combat workhorse:** Spirit Guardians (concentration AoE), Sacred Flame, Toll the Dead
- **Healing:** Mass Healing Word (emergency), Revivify (revive from 0), Cure Wounds upcast
- **Party buffs:** Bless, Beacon of Hope, Aid (always prepared Life)
- **Damage:** Flame Strike at L9

### Tier 3 (Levels 11–15) Spell Priority
- **Boss healing:** Heal (70 HP instantly), Mass Cure Wounds (upcast)
- **Control:** Banishment (Life doesn't get, but general), Hold Person, Spirit Guardians upcast
- **Utility:** Plane Shift, Heroes' Feast (pre-fight long buff)
- **Revival:** Raise Dead, Greater Restoration, Resurrection

### Tier 4 (Levels 16–20) Spell Priority
- **Capstone healing:** Mass Heal (700 HP distributed), True Resurrection
- **Protection:** Holy Aura
- **Nukes:** Sunburst (12d6 radiant + blind)
- **Continuity:** Divine Intervention for any 5th-level-or-lower spell free, scaling to Wish at L20

---

## Magic Item Summary

| Level | Item | Rarity |
|-------|------|--------|
| 5 | +1 Mace | Uncommon |
| 7 | +1 Shield | Uncommon |
| 8 | Periapt of Wound Closure | Uncommon |
| 10 | +1 Half Plate | Rare |
| 11 | Staff of Healing | Rare |
| 13 | Amulet of Health | Rare |
| 15 | Cloak of Protection | Uncommon |
| 17 | Tome of Understanding | Very Rare |
| 20 | +3 Shield | Very Rare |

---

## AC Progression

| Level | Armor | Shield | Cloak/Items | Total AC |
|-------|-------|--------|-------------|----------|
| 1-4 | Scale Mail (14) | Shield (+2) | — | 16 |
| 5-6 | Scale Mail | Shield | — | 16 |
| 7-9 | Scale Mail | +1 Shield (+3) | — | 17 |
| 10-14 | +1 Half Plate (15+2 DEX+1) | +1 Shield (+3) | — | 20 |
| 15-19 | +1 Half Plate | +1 Shield | +Cloak (+1) | 21 |
| 20 | +1 Half Plate | +3 Shield (+5) | Cloak | 23 |

---

## Simulation Notes

**Primary combat pattern:**
- Open with Bless or Spirit Guardians at T2+
- War Caster + Potent Spellcasting means cantrip damage stays relevant (Toll the Dead scales)
- Bonus action: Healing Word to revive downed allies OR hold for emergencies
- Concentration focus: Spirit Guardians is the workhorse; don't break concentration casually
- Preserve Life as heavy AoE heal via Channel Divinity (once Bloodied allies present)

**Healing philosophy:** Healing Word (bonus action revive) > Cure Wounds (action single heal). Use Mass Healing Word when 3+ injured. Save higher slots for Revivify/Raise Dead emergencies.

**Behavior AI priorities:**
1. If any ally at 0 HP: Healing Word to revive (before other spellcasting)
2. If multiple allies Bloodied: Preserve Life via Channel Divinity
3. If encounter is hard/deadly: open with Spirit Guardians
4. If encounter is easy/medium: open with Bless, then Spirit Guardians next turn
5. Bonus action: Spiritual Weapon (if prepared) or Healing Word
6. Maintain concentration on highest-value spell
7. Save Divine Intervention for critical boss turns
